import numpy as np, pandas as pd, json
from scipy.stats import gaussian_kde
exec(open('/home/claude/analisis_unam.py').read().split('if __name__')[0])
d = cargar(); mod = Modelo(d, sorted(d.year.unique()))
ch = np.load(f"{OUT}/chain_full.npy")
tau = np.array([mod.desempaca(t)[0] for t in ch])
s_p = np.array([mod.desempaca(t)[2] for t in ch])
F = {}

# --- Fig 1: trayectoria de tau_t ---
q = np.percentile(tau, [2.5, 16, 50, 84, 97.5], axis=0)
F["tau"] = [{"y": int(y), "q025": float(q[0,k]), "q16": float(q[1,k]), "med": float(q[2,k]),
             "q84": float(q[3,k]), "q975": float(q[4,k])} for k, y in enumerate(mod.anios)]

# --- Fig 2: densidades LOYO de la discrepancia media ---
F["loyo"] = {}
for y in [2024, 2025, 2026]:
    Dm = np.load(f"{OUT}/Dm_{y}.npy"); j = json.load(open(f"{OUT}/loyo_{y}.json"))
    g = np.linspace(Dm.min()-1.5, Dm.max()+1.5, 140); dens = gaussian_kde(Dm)(g)
    F["loyo"][str(y)] = {"grid": [round(float(a),3) for a in g],
                         "dens": [round(float(b),5) for b in dens],
                         "n": j["n"], "q": j["q"], "rmse": j["rmse"]}

# --- Fig 3: heterogeneidad de D en 2026 ---
t26 = pd.read_csv(f"{OUT}/te_2026.csv")
AREAS = {1: "I. F\\'isico-Matem\\'aticas", 2: "II. Biol\\'ogicas y Salud",
         3: "III. Sociales", 4: "IV. Humanidades y Artes"}
F["het_area"] = [{"k": int(a), "lab": AREAS[int(a)], "media": float(g.D_med.mean()),
                  "med": float(g.D_med.median()), "n": int(len(g)),
                  "q25": float(g.D_med.quantile(.25)), "q75": float(g.D_med.quantile(.75))}
                 for a, g in t26.groupby("area")]
F["het_mod"] = [{"lab": str(m), "media": float(g.D_med.mean()), "med": float(g.D_med.median()),
                 "n": int(len(g)), "q25": float(g.D_med.quantile(.25)),
                 "q75": float(g.D_med.quantile(.75))} for m, g in t26.groupby("modalidad")]
# histograma de D por unidad
h, e = np.histogram(t26.D_med, bins=22)
F["hist26"] = {"cent": [round(float(x),2) for x in (e[:-1]+e[1:])/2], "n": [int(x) for x in h]}
F["sens"] = json.load(open(f"{OUT}/sensibilidad.json"))
F["s_post"] = list(map(float, np.percentile(s_p, [2.5, 50, 97.5])))
F["n_obs"] = int(len(mod.d)); F["n_uni"] = int(mod.J)
F["dtau"] = list(map(float, np.percentile(tau[:,-1]-tau[:,-2], [2.5, 50, 97.5])))
json.dump(F, open(f"{OUT}/figdata.json","w"), indent=1)

print("tau:", [(x["y"], round(x["med"],2)) for x in F["tau"]])
print("\nheterogeneidad 2026 por area:")
for x in F["het_area"]: print(f'  {x["k"]}: media={x["media"]:6.2f} mediana={x["med"]:6.2f} n={x["n"]}')
print("por modalidad:")
for x in F["het_mod"]: print(f'  {x["lab"]:14s}: media={x["media"]:6.2f} mediana={x["med"]:6.2f} n={x["n"]}')
print("\nLOYO:", {k: (round(v["q"][1],2), v["n"], round(v["rmse"],2)) for k,v in F["loyo"].items()})
print("s posterior:", np.round(F["s_post"],2), "| dtau:", np.round(F["dtau"],2))
