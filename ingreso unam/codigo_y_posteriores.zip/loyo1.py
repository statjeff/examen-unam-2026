import sys, numpy as np, json
exec(open('/home/claude/analisis_unam.py').read().split('if __name__')[0])
y = int(sys.argv[1])
d = cargar()
r = loyo(d, y, nsteps=6500, ndraw=800)
Dm = r["D"].mean(axis=1); q = np.percentile(Dm, [2.5, 50, 97.5])
rmse = float(np.sqrt((r["D"] ** 2).mean()))
np.save(f"{OUT}/Dm_{y}.npy", Dm); np.save(f"{OUT}/D_{y}.npy", r["D"])
te = r["te"].copy(); te["D_med"] = np.median(r["D"], axis=0); te.to_csv(f"{OUT}/te_{y}.csv", index=False)
json.dump({"n": int(r["n_unidades"]), "q": list(map(float,q)), "rmse": rmse,
           "diag": r["diag"]}, open(f"{OUT}/loyo_{y}.json","w"), indent=1)
print(f"RESULTADO {y}: n={r['n_unidades']} D_media={q[1]:.2f} IC95=[{q[0]:.2f},{q[2]:.2f}] RMSE={rmse:.2f}")
