import sys, numpy as np, json, os
exec(open('/home/claude/analisis_unam.py').read().split('if __name__')[0])
d = cargar(); out = {}
fn = f"{OUT}/sensibilidad.json"
if os.path.exists(fn): out = json.load(open(fn))
for s_fix in [float(a) for a in sys.argv[1:]]:
    class MF(Modelo):
        _s = s_fix
        def desempaca(self, th):
            tau, m, s, sa, se, srw = Modelo.desempaca(self, th)
            return tau, m, self._s, sa, se, srw
    mf = MF(d, sorted(d.year.unique()))
    chf, _, _ = ajustar(mf, nsteps=4500, nwalkers=80, etiqueta=f"s={s_fix}")
    tp = np.array([mf.desempaca(t)[0] for t in chf]); dd = tp[:, -1] - tp[:, -2]
    out[str(s_fix)] = list(map(float, np.percentile(dd, [2.5, 50, 97.5])))
    print(f"RESULTADO s={s_fix}: Delta={out[str(s_fix)][1]:.2f} [{out[str(s_fix)][0]:.2f},{out[str(s_fix)][2]:.2f}]", flush=True)
json.dump(out, open(fn, "w"), indent=1)
